const int sensorPin = A0;   // Photoresistor voltage divider output
const int ledPin = 9;       // LED connected through a 220 ohm resistor
const int threshold = 500;  // Adjust after observing sensor readings

void setup() {
  pinMode(ledPin, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int lightLevel = analogRead(sensorPin); // Read 0-1023
  Serial.print("Light level: ");
  Serial.println(lightLevel);

  // Typical LDR divider: darker conditions give a lower reading
  // with the LDR connected to 5V and the fixed resistor to GND.
  if (lightLevel < threshold) {
    digitalWrite(ledPin, HIGH); // Turn LED on when it is dark
  } else {
    digitalWrite(ledPin, LOW);  // Turn LED off when it is bright
  }

  delay(250);
}